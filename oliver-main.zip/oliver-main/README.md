# Oliver
A Hexo Template

Example: https://el42.cc

![Oliver](https://s2.loli.net/2023/05/18/Pu95OC6fGh2yUvr.png)

## Features
- Responsive Design
- Dark Mode Support
- Simple